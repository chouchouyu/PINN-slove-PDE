import enum

class CallPutType(enum.IntEnum):
    CALL = 1
    PUT = -1